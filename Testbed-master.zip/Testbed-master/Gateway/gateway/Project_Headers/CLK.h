/*
 * CLK.h
 *
 *  Created on: Sep 24, 2013
 *      Author: B46911
 */

#ifndef CLK_H_
#define CLK_H_

void Clk_Init();

#endif /* CLK_H_ */
